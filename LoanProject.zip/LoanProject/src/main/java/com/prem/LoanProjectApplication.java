package com.prem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanProjectApplication.class, args);
	}

}
